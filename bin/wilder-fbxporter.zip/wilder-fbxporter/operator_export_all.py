import bpy

class FBXPORTER_OT_ExportAll(bpy.types.Operator):
    bl_idname = "wilder.fbxporter.export_all"
    bl_label = "Export All"

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        main(context)
        return {'FINISHED'}


def register():
    bpy.utils.register_class(FBXPORTER_OT_ExportAll)


def unregister():
    bpy.utils.unregister_class(FBXPORTER_OT_ExportAll)


if __name__ == "__main__":
    register()
